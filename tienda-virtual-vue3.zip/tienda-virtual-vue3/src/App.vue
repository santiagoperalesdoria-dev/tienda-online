<script setup>
import { computed, ref } from 'vue'
import AppHeader from './components/AppHeader.vue'
import ListaProductos from './components/ListaProductos.vue'
import CarritoCompra from './components/CarritoCompra.vue'
import FacturaCompra from './components/FacturaCompra.vue'
import AppFooter from './components/AppFooter.vue'

const nombreTienda = 'Verde Vivo'
const contacto = 'hola@verdevivo.co'
const anio = new Date().getFullYear()

// El estado compartido vive aquí, en el componente raíz, como pide la guía.
const productos = ref([
  { id: 1, imagen: 'https://images.unsplash.com/photo-1498049794561-7780e7231661?auto=format&fit=crop&w=900&q=85', descripcion: 'Audífonos inalámbricos', detalle: 'Sonido envolvente · Bluetooth 5.3', valor: 189900, descuento: 20, categoria: 'Audio', etiqueta: 'Más vendido' },
  { id: 2, imagen: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=85', descripcion: 'Reloj inteligente', detalle: 'Monitoreo diario · Resistente al agua', valor: 249900, descuento: 15, categoria: 'Accesorios', etiqueta: '' },
  { id: 3, imagen: 'https://images.unsplash.com/photo-1526738549149-8e07eca6c147?auto=format&fit=crop&w=900&q=85', descripcion: 'Parlante portátil', detalle: 'Audio potente · 12 h de batería', valor: 159900, descuento: 10, categoria: 'Audio', etiqueta: 'Oferta' },
  { id: 4, imagen: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=900&q=85', descripcion: 'Portátil ultradelgado', detalle: 'Rendimiento para estudiar y crear', valor: 2899900, descuento: 12, categoria: 'Tecnología', etiqueta: '' },
  { id: 5, imagen: 'https://images.unsplash.com/photo-1512499617640-c74ae3a79d37?auto=format&fit=crop&w=900&q=85', descripcion: 'Cámara compacta', detalle: 'Captura tus momentos favoritos', valor: 429900, descuento: 0, categoria: 'Tecnología', etiqueta: '' },
  { id: 6, imagen: 'https://images.unsplash.com/photo-1583394838336-acd977736f90?auto=format&fit=crop&w=900&q=85', descripcion: 'Audífonos de diadema', detalle: 'Acolchados · Graves profundos', valor: 219900, descuento: 18, categoria: 'Audio', etiqueta: '' },
  { id: 7, imagen: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=85', descripcion: 'Tenis urbanos', detalle: 'Diseño ligero para todos los días', valor: 279900, descuento: 25, categoria: 'Estilo', etiqueta: 'Precio especial' },
  { id: 8, imagen: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=85', descripcion: 'Auriculares premium', detalle: 'Diseño cómodo y sonido nítido', valor: 199900, descuento: 8, categoria: 'Audio', etiqueta: '' }
])

const carrito = ref([])
const mostrarFactura = ref(false)
const numeroFactura = ref(1)
const categoriaActiva = ref('Todos')
const busqueda = ref('')
const aviso = ref('')

const categorias = computed(() => ['Todos', ...new Set(productos.value.map(p => p.categoria))])
const productosFiltrados = computed(() => productos.value.filter(p => {
  const coincideCategoria = categoriaActiva.value === 'Todos' || p.categoria === categoriaActiva.value
  const termino = busqueda.value.trim().toLocaleLowerCase('es')
  const coincideBusqueda = !termino || `${p.descripcion} ${p.detalle} ${p.categoria}`.toLocaleLowerCase('es').includes(termino)
  return coincideCategoria && coincideBusqueda
}))
const cantidadItems = computed(() => carrito.value.reduce((total, item) => total + item.cantidad, 0))

function agregarProducto(producto) {
  const existente = carrito.value.find(item => item.producto.id === producto.id)
  if (existente) {
    carrito.value = carrito.value.map(item => item.producto.id === producto.id
      ? { ...item, cantidad: item.cantidad + 1 }
      : item)
  } else {
    carrito.value = [...carrito.value, { producto, cantidad: 1 }]
  }
  mostrarFactura.value = false
  aviso.value = `${producto.descripcion} se agregó al carrito`
  window.setTimeout(() => { aviso.value = '' }, 2400)
}
function incrementar(id) {
  carrito.value = carrito.value.map(item => item.producto.id === id ? { ...item, cantidad: item.cantidad + 1 } : item)
}
function decrementar(id) {
  carrito.value = carrito.value
    .map(item => item.producto.id === id ? { ...item, cantidad: item.cantidad - 1 } : item)
    .filter(item => item.cantidad > 0)
}
function eliminar(id) {
  carrito.value = carrito.value.filter(item => item.producto.id !== id)
}
function finalizarCompra() {
  if (carrito.value.length) mostrarFactura.value = true
}
function nuevaCompra() {
  carrito.value = []
  mostrarFactura.value = false
  numeroFactura.value += 1
  window.scrollTo({ top: 0, behavior: 'smooth' })
}
function verCarrito() {
  document.getElementById('carrito')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
}
</script>

<template>
  <div class="site-shell">
    <AppHeader
      :nombre-tienda="nombreTienda"
      :cantidad-items="cantidadItems"
      @ver-carrito="verCarrito"
    />

    <main>
      <section class="hero">
        <div class="hero-copy">
          <p class="eyebrow"><span class="eyebrow-dot"></span> Una forma más simple de elegir</p>
          <h1>Pequeños detalles.<br /><span>Grandes experiencias.</span></h1>
          <p class="hero-description">Tecnología y accesorios seleccionados para acompañarte en cada momento.</p>
          <a class="hero-link" href="#catalogo">Explorar productos <span aria-hidden="true">↗</span></a>
          <div class="hero-trust">
            <span><span class="check">✓</span> Compra fácil</span>
            <span><span class="check">✓</span> Productos seleccionados</span>
          </div>
        </div>
        <div class="hero-art" aria-label="Audífonos y accesorios tecnológicos">
          <div class="hero-orbit orbit-one"></div>
          <div class="hero-orbit orbit-two"></div>
          <div class="hero-sticker"><span>Selección</span><strong>para ti</strong></div>
          <img src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=1100&q=90" alt="Audífonos modernos" />
          <div class="hero-caption"><span class="caption-mark">✳</span><span><strong>Encuentra tu favorito</strong><small>Ideas para todos los días</small></span></div>
        </div>
        <div class="hero-number">01 <span>/ COLECCIÓN</span></div>
      </section>

      <section class="benefits" aria-label="Beneficios de la tienda">
        <div class="benefit"><span class="benefit-icon">◇</span><span><strong>Selección cuidada</strong><small>Productos para tu día a día</small></span></div>
        <div class="benefit"><span class="benefit-icon">↗</span><span><strong>Compra sencilla</strong><small>Agrega y revisa tu carrito</small></span></div>
        <div class="benefit"><span class="benefit-icon">♡</span><span><strong>Hecho para ti</strong><small>Encuentra algo que te guste</small></span></div>
      </section>

      <section id="catalogo" class="catalog-section">
        <div class="section-heading">
          <div>
            <p class="eyebrow">LA COLECCIÓN</p>
            <h2>Descubre tus <em>favoritos.</em></h2>
            <p class="section-subtitle">Una selección de tecnología y accesorios para tu rutina.</p>
          </div>
          <div class="catalog-count"><strong>{{ productosFiltrados.length.toString().padStart(2, '0') }}</strong><span> productos</span></div>
        </div>

        <div class="catalog-tools">
          <div class="category-list" aria-label="Filtrar por categoría">
            <button
              v-for="categoria in categorias"
              :key="categoria"
              class="category-chip"
              :class="{ active: categoriaActiva === categoria }"
              @click="categoriaActiva = categoria"
            >{{ categoria }}</button>
          </div>
          <label class="search-box">
            <span aria-hidden="true">⌕</span>
            <input v-model="busqueda" type="search" placeholder="Buscar producto..." aria-label="Buscar producto" />
          </label>
        </div>

        <ListaProductos :productos="productosFiltrados" @agregar-producto="agregarProducto" />
        <div v-if="productosFiltrados.length === 0" class="empty-search">
          <span>⌕</span><strong>No encontramos productos</strong><p>Prueba con otro nombre o categoría.</p>
          <button class="text-button" @click="busqueda = ''; categoriaActiva = 'Todos'">Ver todos los productos</button>
        </div>
      </section>

      <section class="promo-strip">
        <div class="promo-symbol">✳</div>
        <div><p class="eyebrow">UN BUEN HALLAZGO TE ESPERA</p><h2>Tu próxima cosa favorita<br />puede estar aquí.</h2></div>
        <a href="#catalogo">Ver colección <span>↗</span></a>
        <div class="promo-decoration">VV.</div>
      </section>

      <section id="carrito" class="cart-section">
        <div class="section-heading cart-heading">
          <div><p class="eyebrow">TU SELECCIÓN</p><h2>El carrito <em>de compra.</em></h2><p class="section-subtitle">Revisa tus productos antes de finalizar.</p></div>
          <div class="cart-count"><span>{{ cantidadItems.toString().padStart(2, '0') }}</span> unidades</div>
        </div>
        <CarritoCompra
          :items="carrito"
          @incrementar="incrementar"
          @decrementar="decrementar"
          @eliminar="eliminar"
          @finalizar-compra="finalizarCompra"
        />
      </section>

      <section v-if="mostrarFactura" id="factura" class="invoice-section">
        <FacturaCompra
          :items="carrito"
          :numero-factura="String(numeroFactura).padStart(5, '0')"
          :fecha="new Date().toLocaleDateString('es-CO', { year: 'numeric', month: 'long', day: 'numeric' })"
          @nueva-compra="nuevaCompra"
        />
      </section>
    </main>

    <div v-if="aviso" class="toast" role="status"><span>✓</span>{{ aviso }}</div>
    <AppFooter :nombre-tienda="nombreTienda" :anio="anio" :contacto="contacto" />
  </div>
</template>