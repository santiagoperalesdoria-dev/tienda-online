<script setup>
defineProps({
  nombreTienda: { type: String, required: true },
  anio: { type: Number, default: () => new Date().getFullYear() },
  contacto: { type: String, default: 'hola@verdevivo.co' }
})
</script>

<template>
  <footer class="site-footer">
    <div class="footer-main">
      <a class="brand footer-brand" href="#">
        <span class="brand-mark"><span></span><span></span><span></span></span>
        <span class="brand-name">{{ nombreTienda }}<small>OBJETOS PARA VIVIR MEJOR</small></span>
      </a>
      <p>Objetos útiles, diseño sencillo<br />y pequeños detalles para tu día.</p>
      <div class="footer-contact"><span>¿Tienes alguna pregunta?</span><a :href="`mailto:${contacto}`">{{ contacto }}</a></div>
    </div>
    <div class="footer-bottom"><span>© {{ anio }} {{ nombreTienda }}. Proyecto académico.</span><a href="#catalogo">Volver arriba ↑</a><span>Diseñado con cuidado en Colombia</span></div>
  </footer>
</template>