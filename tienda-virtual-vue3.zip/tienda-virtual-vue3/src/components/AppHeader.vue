<script setup>
defineProps({
  nombreTienda: { type: String, required: true },
  cantidadItems: { type: Number, default: 0 }
})
defineEmits(['ver-carrito'])
</script>

<template>
  <header class="site-header">
    <a class="brand" href="#" :aria-label="`${nombreTienda}, inicio`">
      <span class="brand-mark"><span></span><span></span><span></span></span>
      <span class="brand-name">{{ nombreTienda }}<small>OBJETOS PARA VIVIR MEJOR</small></span>
    </a>
    <nav class="main-nav" aria-label="Navegación principal">
      <a href="#catalogo">Colección</a>
      <a href="#carrito">Cómo comprar</a>
    </nav>
    <button class="header-cart" @click="$emit('ver-carrito')" aria-label="Ver carrito de compra">
      <span class="bag-icon">♧</span><span class="cart-label">Mi carrito</span>
      <span class="cart-bubble">{{ cantidadItems }}</span>
    </button>
  </header>
</template>