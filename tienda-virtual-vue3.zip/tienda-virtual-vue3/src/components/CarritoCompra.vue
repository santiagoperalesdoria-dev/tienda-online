<script setup>
import { computed } from 'vue'

const props = defineProps({
  items: { type: Array, required: true, default: () => [] }
})
const emit = defineEmits(['incrementar', 'decrementar', 'eliminar', 'finalizar-compra'])
const formatoCOP = valor => new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(valor)
const subtotal = computed(() => props.items.reduce((suma, item) => suma + item.producto.valor * item.cantidad, 0))
const totalDescuentos = computed(() => props.items.reduce((suma, item) => suma + (item.producto.valor - Math.round(item.producto.valor * (1 - item.producto.descuento / 100))) * item.cantidad, 0))
const total = computed(() => subtotal.value - totalDescuentos.value)
</script>

<template>
  <div class="cart-layout">
    <div class="cart-items-panel">
      <div v-if="items.length === 0" class="empty-cart">
        <div class="empty-cart-icon">♧</div>
        <h3>Tu carrito está esperando.</h3>
        <p>Cuando encuentres algo que te guste, agrégalo aquí y aparecerá en esta lista.</p>
        <a href="#catalogo" class="outline-button">Explorar colección <span>↗</span></a>
      </div>
      <template v-else>
        <div class="cart-table-head"><span>PRODUCTO</span><span>PRECIO</span><span>CANTIDAD</span><span>TOTAL</span></div>
        <article v-for="item in items" :key="item.producto.id" class="cart-line">
          <div class="cart-product">
            <img :src="item.producto.imagen" :alt="item.producto.descripcion" />
            <div><strong>{{ item.producto.descripcion }}</strong><small>{{ item.producto.categoria }}</small><button class="remove-link" @click="emit('eliminar', item.producto.id)">Eliminar</button></div>
          </div>
          <div class="cart-unit">{{ formatoCOP(Math.round(item.producto.valor * (1 - item.producto.descuento / 100))) }}</div>
          <div class="quantity-control">
            <button @click="emit('decrementar', item.producto.id)" :aria-label="`Disminuir cantidad de ${item.producto.descripcion}`">−</button>
            <span>{{ item.cantidad }}</span>
            <button @click="emit('incrementar', item.producto.id)" :aria-label="`Aumentar cantidad de ${item.producto.descripcion}`">+</button>
          </div>
          <strong class="cart-line-total">{{ formatoCOP(Math.round(item.producto.valor * (1 - item.producto.descuento / 100)) * item.cantidad) }}</strong>
        </article>
      </template>
    </div>
    <aside class="order-summary">
      <p class="eyebrow">RESUMEN</p>
      <h3>Tu pedido</h3>
      <div class="summary-row"><span>Subtotal (precio regular)</span><span>{{ formatoCOP(subtotal) }}</span></div>
      <div class="summary-row discount-row"><span>Descuentos</span><span>− {{ formatoCOP(totalDescuentos) }}</span></div>
      <div class="summary-row"><span>Envío</span><span class="shipping-free">Por calcular</span></div>
      <div class="summary-total"><span>Total productos</span><strong>{{ formatoCOP(total) }}</strong></div>
      <p class="summary-note">El IVA del 19 % se discrimina en la factura final.</p>
      <button class="checkout-button" :disabled="items.length === 0" @click="emit('finalizar-compra')">Finalizar compra <span>↗</span></button>
      <div class="secure-note"><span>◇</span> Resumen actualizado automáticamente</div>
    </aside>
  </div>
</template>