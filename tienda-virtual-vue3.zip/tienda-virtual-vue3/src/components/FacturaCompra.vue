<script setup>
import { computed } from 'vue'

const props = defineProps({
  items: { type: Array, required: true },
  numeroFactura: { type: String, required: true },
  fecha: { type: String, required: true }
})
const emit = defineEmits(['nueva-compra'])
const formatoCOP = valor => new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(valor)
const subtotalRegular = computed(() => props.items.reduce((s, item) => s + sValor(item) * item.cantidad, 0))
function sValor(item) { return item.producto.valor }
const descuentos = computed(() => props.items.reduce((s, item) => s + (item.producto.valor - Math.round(item.producto.valor * (1 - item.producto.descuento / 100))) * item.cantidad, 0))
const subtotalConDescuento = computed(() => subtotalRegular.value - descuentos.value)
const iva = computed(() => Math.round(subtotalConDescuento.value * 0.19))
const totalPagar = computed(() => subtotalConDescuento.value + iva.value)
function imprimirFactura() { window.print() }
</script>

<template>
  <div class="invoice-card">
    <div class="invoice-top">
      <div class="invoice-brand"><span class="brand-mark"><span></span><span></span><span></span></span><strong>Verde Vivo</strong></div>
      <div class="invoice-stamp"><span>COMPROBANTE DE COMPRA</span><strong>Factura #{{ numeroFactura }}</strong><small>{{ fecha }}</small></div>
    </div>
    <div class="invoice-success"><span>✓</span><div><h2>¡Gracias por tu compra!</h2><p>Este es el resumen de los productos seleccionados.</p></div></div>
    <div class="invoice-table-wrap">
      <table class="invoice-table">
        <thead><tr><th>Descripción</th><th>Cant.</th><th>Valor unitario</th><th>Desc.</th><th>Valor con desc.</th><th>Subtotal</th></tr></thead>
        <tbody>
          <tr v-for="item in items" :key="item.producto.id">
            <td>{{ item.producto.descripcion }}</td>
            <td>{{ item.cantidad }}</td>
            <td>{{ formatoCOP(item.producto.valor) }}</td>
            <td>{{ item.producto.descuento }}%</td>
            <td>{{ formatoCOP(Math.round(item.producto.valor * (1 - item.producto.descuento / 100))) }}</td>
            <td>{{ formatoCOP(Math.round(item.producto.valor * (1 - item.producto.descuento / 100)) * item.cantidad) }}</td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="invoice-bottom">
      <div class="invoice-message"><span>✳</span><p>Gracias por elegir <strong>Verde Vivo</strong>.<br />Esperamos verte de nuevo pronto.</p></div>
      <div class="invoice-totals">
        <div><span>Subtotal regular</span><span>{{ formatoCOP(subtotalRegular) }}</span></div>
        <div class="discount-row"><span>Total descuentos</span><span>− {{ formatoCOP(descuentos) }}</span></div>
        <div><span>Subtotal con descuento</span><span>{{ formatoCOP(subtotalConDescuento) }}</span></div>
        <div><span>IVA (19 %)</span><span>{{ formatoCOP(iva) }}</span></div>
        <div class="invoice-grand-total"><strong>Total a pagar</strong><strong>{{ formatoCOP(totalPagar) }}</strong></div>
      </div>
    </div>
    <div class="invoice-actions"><button class="outline-button" @click="imprimirFactura">Imprimir factura <span>↗</span></button><button class="checkout-button" @click="emit('nueva-compra')">Nueva compra <span>↗</span></button></div>
    <p class="invoice-disclaimer">Comprobante demostrativo para actividad académica. El envío no está incluido.</p>
  </div>
</template>