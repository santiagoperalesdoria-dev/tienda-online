<script setup>
import ProductoCard from './ProductoCard.vue'

defineProps({
  productos: { type: Array, required: true, default: () => [] }
})
const emit = defineEmits(['agregar-producto'])
function reenviarProducto(producto) {
  emit('agregar-producto', producto)
}
</script>

<template>
  <div class="product-grid">
    <ProductoCard
      v-for="producto in productos"
      :key="producto.id"
      :producto="producto"
      @agregar-al-carrito="reenviarProducto"
    />
  </div>
</template>