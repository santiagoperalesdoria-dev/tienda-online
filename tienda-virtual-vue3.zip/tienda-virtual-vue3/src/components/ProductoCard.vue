<script setup>
import { computed } from 'vue'

const props = defineProps({
  producto: {
    type: Object,
    required: true,
    validator: value => ['id', 'imagen', 'descripcion', 'valor', 'descuento'].every(key => key in value)
  }
})
const emit = defineEmits(['agregar-al-carrito'])
const valorConDescuento = computed(() => Math.round(props.producto.valor * (1 - props.producto.descuento / 100)))
const formatoCOP = valor => new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(valor)
</script>

<template>
  <article class="product-card">
    <div class="product-image-wrap">
      <img class="product-image" :src="producto.imagen" :alt="producto.descripcion" loading="lazy" />
      <span v-if="producto.descuento > 0" class="discount-tag">-{{ producto.descuento }}%</span>
      <span v-if="producto.etiqueta" class="product-label">{{ producto.etiqueta }}</span>
      <button class="quick-add" @click="emit('agregar-al-carrito', producto)" :aria-label="`Agregar ${producto.descripcion} al carrito`">+</button>
    </div>
    <div class="product-info">
      <div class="product-meta"><span>{{ producto.categoria }}</span><span class="product-dot">●</span><span>Verde Vivo</span></div>
      <h3>{{ producto.descripcion }}</h3>
      <p class="product-description">{{ producto.detalle }}</p>
      <div class="price-row">
        <div class="prices">
          <span v-if="producto.descuento > 0" class="old-price">{{ formatoCOP(producto.valor) }}</span>
          <strong class="current-price">{{ formatoCOP(valorConDescuento) }}</strong>
        </div>
        <button class="add-button" @click="emit('agregar-al-carrito', producto)">Agregar <span>↗</span></button>
      </div>
    </div>
  </article>
</template>